package com.loops.demo;

import java.util.Scanner;

public class Loop003 {

	public static void main(String[] args) {
		// finding max and min from the given numbers;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the range: ");
		int range = scan.nextInt();
		
		int max = -100000;
		int min = 100000;
		for(int i = 1; i <= range; i++) {
			System.out.println("Enter a number: ");
			int n = scan.nextInt();
			
			if(n > max) {
				max = n;
			}
			
			if(n < min) {
				min = n;
			}
			
		}
		
		System.out.println("Minimum: " + min);
		System.out.println("Maximum: " + max);
		
		scan.close();

	}

}
