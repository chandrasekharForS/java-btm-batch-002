package com.decisions.demo;

import java.util.Scanner;

public class If003 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a character: ");
		char ch = scanner.next().charAt(0);
		
		if(ch == 'a') {
			System.out.println("Vowel");
		}
		else if(ch == 'e') {
			System.out.println("Vowel");
		}
		else if(ch == 'i') {
			System.out.println("Vowel");
		}
		else if(ch == 'o') {
			System.out.println("Vowel");
		}
		else if(ch == 'u') {
			System.out.println("Vowel");
		}
		else if(ch == 'A') {
			System.out.println("Vowel");
		}
		else if(ch == 'E') {
			System.out.println("Vowel");
		}
		else if(ch == 'I') {
			System.out.println("Vowel");
		}
		else if(ch == 'O') {
			System.out.println("Vowel");
		}
		else if(ch == 'U') {
			System.out.println("Vowel");
		}
		else {
			System.out.println("Consonant.");
		}
		
		scanner.close();
	}

}
