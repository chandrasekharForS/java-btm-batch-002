package com.loops.demo;

import java.util.Scanner;

public class Loop007 {

	public static void main(String[] args) {
		// 1^1 - 2^2 + 3^3 - 4^4 + 5^5 - 6^6... n
		
		if(op == '+') {
			op = '-';
			
			// addition
		}
		else if(op == '-') {
			op = '+';
			// subtraction
		}
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the range: ");
		int r = scan.nextInt();
		
		int sumOfSeries = 0;
		
		for(int i = 1; i <= r; i++) {
			int product=1;
			
			for(int j = 1; j <= i; j++) {
				product = product * i; 
			}
			
			sumOfSeries = sumOfSeries + product;
		}
		
		System.out.println("Sum of the series: " + sumOfSeries);
		
		scan.close();

	}

}
