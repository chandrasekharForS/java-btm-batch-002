package com.loops.demo;

public class Loop001 {

	public static void main(String[] args) {
		// 1. while
		
		/*int i = 1;
		
		while(i <= 5) {
			System.out.println(i);
			i = i + 1;
		}
		*/
		
		// 2. do while
		
		/*int i = 1;
		
		do {
			System.out.println(i);
			i = i + 1;
		} while(i <= 5);
		*/
		
		//3. for
		/*for(int i = 1; i <= 5; i++) {
			System.out.println(i);
		}
		*/
		// 4. for each
		/*int numbers[] = {1, 2, 3, 4, 5, 6};
		for(int num : numbers) {
			System.out.println(num);
		}*/
		
	}

}

/*
1
2
3
4
5

i = 1

1. i <= 5 => 1 <= 5 == true
	i = i + 1
	  = 1 + 1
	  = 2
2. i <= 5 => 2 <= 5 == true
	i = i + 1
	  = 2 + 1
	  = 3
3. i <= 5 => 3 <= 5 == true
	i = i + 1
	  = 3 + 1
	  = 4
4. i <= 5 => 4 <= 5 == true
	i = i + 1
	  = 4 + 1
	  = 5
5. i <= 5  => 5 <= 5 == true
	i = i + 1
	  = 5 + 1
	  = 6
6. i <= 5 => 6 <= 5 == false
*/

