
public class Sum {

	public static void main(String[] args) {
		//final int n1 = 100;
		int n1 = 100;
		int n2 = 200;
		
		int r = n1 + n2;
		
		System.out.println("Sum: " + r);
		
		n1 = 250;
		

	}

}
