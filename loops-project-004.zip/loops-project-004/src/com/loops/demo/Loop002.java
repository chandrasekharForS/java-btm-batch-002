package com.loops.demo;

import java.util.Scanner;

public class Loop002 {

	public static void main(String[] args) {
		// while
		/*int i = 1;
		
		int sum = 0;
		
		while(i <= 5) {
			sum = sum + i;
			i = i + 1;
		}
		
		System.out.println("Total: " + sum);
		*/
		
		// for
		/*int sum = 0;
		
		for(int i = 1; i <= 5; i++) {
			sum = sum + i;
		}
		
		System.out.println("Total: " + sum);
		*/
		
		/*Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the range: ");
		int range = scan.nextInt();
		
		int total = 0;
		
		for(int i = 1; i <= range; i++) {
			total = total + i;
		}
		
		System.out.println("Total: " + total);
		
		
		
		
		scan.close();
		*/
		
	}

}

/*
s = 0
i = 1

1. i <= 5 ==> 1 <= 5 == true
	s =  s + i
	  =  0 + 1
	  = 1
	  
	i = i + 1
	  = 1 + 1
	  = 2
2. i <= 5 ==> 2 <= 5 == true
	s = s + i
	  = 1 + 2
	  = 3
	  
	i = i + 1
	  = 2 + 1
	  = 3
3. i <= 5 ==> 3 <= 5== true
	s = s + i
	  = 3 + 3
	  = 6
	  
	i = i + 1
	  = 3 + 1
	  = 4
4. i <= 5 ==> 4 <= 5 == true
	s = s + i
	  = 6 + 4
	  = 10
	  
	i = i + 1
	  = 4 + 1
	  = 5
5. i <= 5 ==> 5 <= 5 == true
    s = s + i
      = 10 + 5
      = 15
      
    i = i + 1
      = 5 + 1
      = 6
6. i <= 5 ==> 6 <= 5 == false
	  
*/
