package com.loops.demo;

import java.util.Scanner;

public class Loop004 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter a number to find its factorial: ");
		int num = scanner.nextInt();
		
		// 5 = 5 * 4 * 3 * 2 * 1
		int fact = 1;
		
		/*for(int i = num; i >= 2; i--) {
			fact = fact * i;
		}
		*/
		
		for(int i = 2; i <= num; i++) {
			fact = fact * i;
		}
		System.out.println("Factorial: " + fact);
		
		scanner.close();

	}

}
