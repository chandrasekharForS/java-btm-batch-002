
import java.util.Scanner;

public class Add {

	public static void main(String[] args) {
		int n1, n2, r;
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter number1: ");
		n1 = s.nextInt();
		
		System.out.println("Enter number2: ");
		n2 = s.nextInt();
		
		r = n1 + n2;
		
		System.out.println("Sum: " + r);
		
		
	}

}
