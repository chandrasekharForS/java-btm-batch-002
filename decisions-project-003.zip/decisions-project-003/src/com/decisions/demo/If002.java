package com.decisions.demo;

import java.util.Scanner;

public class If002 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num = scanner.nextInt();
		
		if(num > 0) {
			if(num % 2 == 0) {
				System.out.println("Even.");
			}
			else {
				System.out.println("Odd.");
			}
		}
		else {
			System.out.println("Invalid input.");
		}
		
		scanner.close();

	}

}
