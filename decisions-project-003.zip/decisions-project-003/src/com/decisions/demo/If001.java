package com.decisions.demo;

import java.util.Scanner;

public class If001 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter number1: ");
		int n1 = scanner.nextInt();
		
		System.out.println("Enter number2: ");
		int n2 = scanner.nextInt();
		
		// 1. if
		/*if(n1 > n2) {
			System.out.println("N1 is big.");
		}
		*/
		
		// 2. if else
		/*if(n1 > n2) {
			System.out.println("N1 is big.");
		}
		else {
			System.out.println("N2 is big.");
		}*/
		
		// 3. if else if
		if(n1 > n2) {
			System.out.println("N1 is big.");
		}
		else if(n2 > n1) {
			System.out.println("N2 is big.");
		}
		else {
			System.out.println("Both are equal.");
		}
		
		System.out.println("Program has finished.");
		
		
		scanner.close();
	}

}
