package com.decisions.demo;

import java.util.Scanner;

public class If005 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter number1: ");
		int n1 = scan.nextInt();
		
		System.out.println("Enter number2: ");
		int n2 = scan.nextInt();
		
		System.out.println("Enter number3: ");
		int n3 = scan.nextInt();

		if(n1 > n2 && n1 > n3) {
			System.out.println("N1 is big.");
		}
		else if(n2 > n1 && n2 > n3) {
			System.out.println("N2 is big.");
		}
		else {
			System.out.println("N3 is big");
		}
		
		scan.close();

	}

}
